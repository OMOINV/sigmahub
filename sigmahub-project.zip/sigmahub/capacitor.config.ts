import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.sigmahub.app',
  appName: 'SigmaHub',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  ios: {
    contentInset: 'automatic',
    preferredContentMode: 'mobile',
    backgroundColor: '#0a0e17',
    scheme: 'SigmaHub'
  },
  plugins: {
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#0a0e17'
    },
    SplashScreen: {
      launchAutoHide: true,
      backgroundColor: '#0a0e17',
      showSpinner: false,
      androidSplashResourceName: 'splash',
      splashFullScreen: true,
      splashImmersive: true
    }
  }
};

export default config;
