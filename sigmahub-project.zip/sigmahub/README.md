# SigmaHub — Combined Trading Intelligence Hub

> Cycles · Trends · Edge

A comprehensive trading dashboard combining **Minervini Trend Template** screening, **Armstrong/Shemitah/Mayan cycle analysis**, **Weinstein Stage Analysis**, and **Zweig Breadth Thrust** indicators into one mobile-ready progressive web app.

---

## 🚀 Quick Start (Local Development)

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Open http://localhost:5173
```

---

## 📱 OPTION 1: Deploy to Vercel (Easiest — 5 Minutes)

This gets your app live on the web and accessible from any phone immediately.

### Steps:

1. **Create a GitHub repo:**
   ```bash
   git init
   git add .
   git commit -m "Initial SigmaHub"
   ```
   Push to GitHub (create repo at github.com/new).

2. **Deploy to Vercel:**
   - Go to [vercel.com](https://vercel.com) and sign in with GitHub
   - Click "Import Project" → select your SigmaHub repo
   - Framework: **Vite** (auto-detected)
   - Click **Deploy**
   - Done! You'll get a URL like `sigmahub.vercel.app`

3. **Custom domain (optional):**
   - In Vercel dashboard → Settings → Domains
   - Add your domain and update DNS

### Alternative: Deploy via CLI
```bash
npm install -g vercel
npm run build
vercel --prod
```

---

## 📱 OPTION 2: PWA (Add to Home Screen — iPhone/Android)

The app is **already PWA-ready**. Once deployed to Vercel (or any HTTPS host):

### iPhone:
1. Open your deployed URL in **Safari**
2. Tap the **Share** button (box with arrow)
3. Scroll down and tap **"Add to Home Screen"**
4. Name it "SigmaHub" and tap **Add**
5. It now appears as an app icon on your home screen!

### Android:
1. Open the URL in **Chrome**
2. Chrome will show an **"Add to Home Screen"** banner automatically
3. Or tap ⋮ menu → "Install app"

### Features when installed as PWA:
- Full-screen (no browser chrome)
- Works offline for cached data
- App-like experience with splash screen
- Receives updates automatically

---

## 📱 OPTION 3: Native iPhone App (Capacitor)

For a true App Store app with push notifications, background updates, etc.

### Prerequisites:
- macOS with **Xcode** installed
- Apple Developer Account ($99/year) for App Store distribution
- Node.js 18+

### Steps:

1. **Install dependencies:**
   ```bash
   npm install
   npm install @capacitor/core @capacitor/cli @capacitor/ios
   ```

2. **Build the web app:**
   ```bash
   npm run build
   ```

3. **Initialize Capacitor:**
   ```bash
   npx cap init SigmaHub com.sigmahub.app --web-dir dist
   ```

4. **Add iOS platform:**
   ```bash
   npx cap add ios
   ```

5. **Sync and open in Xcode:**
   ```bash
   npx cap sync
   npx cap open ios
   ```

6. **In Xcode:**
   - Select your signing team
   - Choose a target device or simulator
   - Press ▶ to build and run

7. **For App Store submission:**
   - Archive the build in Xcode (Product → Archive)
   - Upload to App Store Connect
   - Submit for review

### Adding Native Features:
```bash
# Push notifications
npm install @capacitor/push-notifications

# Background fetch (for price alerts)
npm install @capacitor/background-runner

# Haptic feedback
npm install @capacitor/haptics

# Local notifications (cycle alerts)
npm install @capacitor/local-notifications
```

---

## 🔧 Adding Live Market Data

The current build uses mock data. To connect live data:

### Free APIs:
- **Yahoo Finance** (via `yahoo-finance2` npm package)
- **Alpha Vantage** (free tier: 5 calls/min)
- **Finnhub** (60 calls/min free)
- **Polygon.io** (5 calls/min free)

### Example integration:
```javascript
// src/api/market.js
const API_KEY = 'your_key_here';

export async function getQuote(symbol) {
  const res = await fetch(
    `https://finnhub.io/api/v1/quote?symbol=${symbol}&token=${API_KEY}`
  );
  return res.json();
}

export async function getRS(symbol) {
  // Calculate relative strength vs SPY
  const [stock, spy] = await Promise.all([
    getQuote(symbol),
    getQuote('SPY')
  ]);
  // ... RS calculation logic
}
```

### For real-time updates:
```javascript
// WebSocket for live prices
const socket = new WebSocket(`wss://ws.finnhub.io?token=${API_KEY}`);
socket.send(JSON.stringify({ type: 'subscribe', symbol: 'NVDA' }));
socket.onmessage = (event) => {
  const data = JSON.parse(event.data);
  // Update state with live prices
};
```

---

## 📂 Project Structure

```
sigmahub/
├── index.html              # Entry point with PWA meta tags
├── package.json            # Dependencies & scripts
├── vite.config.js          # Vite + PWA plugin config
├── capacitor.config.ts     # Capacitor (native app) config
├── public/
│   └── favicon.svg         # App icon
├── src/
│   ├── main.jsx            # React entry
│   └── App.jsx             # Main SigmaHub component
└── README.md               # This file
```

---

## 🎨 Customization

### Adjusting Cycle Parameters:
Edit the `CYCLES` array in `App.jsx` to update cycle data, dates, and confidence levels.

### Adding New Stocks to Scanner:
Edit the `MTT_RESULTS` array with new stock data. When connected to a live API, this will be automatic.

### Modifying the Watchlist:
Edit the `WATCHLIST` array with your current positions, entries, stops, and targets.

---

## 📋 Recommended Deployment Path

1. **Today:** Deploy to Vercel → Add to iPhone as PWA
2. **This week:** Connect a free market data API for live prices
3. **Later:** If you want App Store presence, use Capacitor to wrap it

The PWA approach gives you 90% of the native app experience with 10% of the effort. Only go the Capacitor route if you specifically need push notifications or App Store distribution.

---

Built with React + Vite • Styled for Bloomberg Terminal aesthetics • PWA + Capacitor ready
