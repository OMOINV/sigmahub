import React from 'react';
import ReactDOM from 'react-dom/client';
import TradingHub from './App';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <TradingHub />
  </React.StrictMode>
);
