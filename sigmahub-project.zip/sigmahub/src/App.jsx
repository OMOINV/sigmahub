import { useState, useEffect, useCallback, useRef } from "react";

const TABS = ["Dashboard", "MTT Scanner", "Cycle Engine", "Stage Analysis", "Watchlist"];

// ── Color System ──
const C = {
  bg: "#0a0e17",
  surface: "#111827",
  card: "#1a2235",
  border: "#1e293b",
  borderLight: "#334155",
  text: "#e2e8f0",
  textDim: "#94a3b8",
  textMuted: "#64748b",
  accent: "#00e5a0",
  accentDim: "#00e5a044",
  warn: "#f59e0b",
  warnDim: "#f59e0b33",
  danger: "#ef4444",
  dangerDim: "#ef444433",
  blue: "#3b82f6",
  blueDim: "#3b82f633",
  purple: "#a78bfa",
};

// ── Utility Fns ──
const fmt = (n, d = 2) => (n != null ? Number(n).toFixed(d) : "—");
const pct = (n) => (n != null ? `${n >= 0 ? "+" : ""}${Number(n).toFixed(2)}%` : "—");
const pctColor = (n) => (n >= 0 ? C.accent : C.danger);

// ── Mock Data ──
const MARKET_DATA = [
  { sym: "SPY", name: "S&P 500", price: 608.72, chg: 1.23, vol: "84.2M" },
  { sym: "QQQ", name: "Nasdaq 100", price: 531.45, chg: 0.87, vol: "62.1M" },
  { sym: "IWM", name: "Russell 2000", price: 224.18, chg: -0.42, vol: "31.5M" },
  { sym: "DIA", name: "Dow Jones", price: 447.33, chg: 0.56, vol: "18.7M" },
  { sym: "GLD", name: "Gold", price: 289.14, chg: 1.89, vol: "12.3M" },
  { sym: "SLV", name: "Silver", price: 33.21, chg: 2.45, vol: "28.9M" },
  { sym: "TLT", name: "20Y Treasury", price: 87.62, chg: -0.78, vol: "22.1M" },
  { sym: "VIX", name: "Volatility", price: 15.32, chg: -5.21, vol: "—" },
];

const MTT_RESULTS = [
  { sym: "NVDA", price: 142.50, rs: 97, stage: 2, sma50: 135.20, sma150: 118.40, sma200: 108.90, high52: 149.80, low52: 60.10, score: 9.2, pass: true },
  { sym: "ACMR", price: 28.75, rs: 94, stage: 2, sma50: 25.10, sma150: 21.80, sma200: 19.50, high52: 30.20, low52: 11.40, score: 8.8, pass: true },
  { sym: "PLTR", price: 78.30, rs: 96, stage: 2, sma50: 72.40, sma150: 55.20, sma200: 42.80, high52: 82.10, low52: 16.90, score: 8.5, pass: true },
  { sym: "CRK", price: 18.42, rs: 82, stage: 1, sma50: 17.80, sma150: 16.90, sma200: 15.60, high52: 19.50, low52: 8.20, score: 7.1, pass: false },
  { sym: "TSLA", price: 342.10, rs: 91, stage: 2, sma50: 318.50, sma150: 275.40, sma200: 245.80, high52: 365.20, low52: 138.80, score: 8.1, pass: true },
  { sym: "AAPL", price: 248.90, rs: 78, stage: 3, sma50: 245.20, sma150: 238.10, sma200: 225.50, high52: 260.10, low52: 164.20, score: 5.4, pass: false },
  { sym: "COIN", price: 298.40, rs: 93, stage: 2, sma50: 272.30, sma150: 228.50, sma200: 198.70, high52: 310.50, low52: 114.80, score: 8.6, pass: true },
  { sym: "MSTR", price: 385.20, rs: 95, stage: 2, sma50: 352.10, sma150: 298.40, sma200: 245.90, high52: 405.80, low52: 92.30, score: 8.9, pass: true },
];

const CYCLES = [
  { name: "Armstrong Pi (8.6yr)", current: "Turning", next: "2026.27", phase: "Peak → Decline", confidence: 92, color: C.accent },
  { name: "Shemitah (7yr)", current: "Year 6", next: "Sep 2025", phase: "Pre-Release", confidence: 85, color: C.warn },
  { name: "Mayan Katun", current: "K'atun 1 Ajaw", next: "2032", phase: "Transition Era", confidence: 78, color: C.purple },
  { name: "Kondratieff Winter", current: "Late Winter", next: "2028-2032", phase: "Deflation Risk", confidence: 70, color: C.blue },
  { name: "262-Day Financial", current: "Day 187", next: "~82 days", phase: "Mid-Cycle", confidence: 88, color: C.accent },
  { name: "Benner Cycle", current: "Panic Year", next: "2026", phase: "Approaching", confidence: 75, color: C.danger },
];

const CONVERGENCE_ZONES = [
  { date: "Q1 2026", cycles: 4, label: "Major Convergence", severity: "critical" },
  { date: "Q3 2026", cycles: 3, label: "Secondary Convergence", severity: "high" },
  { date: "Q1 2027", cycles: 2, label: "Minor Convergence", severity: "medium" },
];

const WATCHLIST = [
  { sym: "NVDA", entry: 128.50, current: 142.50, stop: 118.00, target: 165.00, notes: "AI leader, Stage 2 confirmed" },
  { sym: "ACMR", entry: 22.40, current: 28.75, stop: 19.80, target: 38.00, notes: "Semiconductor play, strong RS" },
  { sym: "CRK", entry: null, current: 18.42, stop: 15.50, target: 24.00, notes: "Nat gas leverage, watching for Stage 2 entry" },
  { sym: "SLV", entry: 28.50, current: 33.21, stop: 26.00, target: 42.00, notes: "SHFE short squeeze thesis" },
  { sym: "MSTR", entry: 310.00, current: 385.20, stop: 280.00, target: 500.00, notes: "BTC proxy, cycle alignment" },
];

// ── Sparkline Component ──
function Sparkline({ data, color = C.accent, width = 80, height = 28 }) {
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const points = data.map((v, i) => `${(i / (data.length - 1)) * width},${height - ((v - min) / range) * height}`).join(" ");
  return (
    <svg width={width} height={height} style={{ display: "block" }}>
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// ── Gauge Component ──
function Gauge({ value, max = 100, label, color = C.accent, size = 80 }) {
  const pctVal = (value / max) * 100;
  const r = (size - 10) / 2;
  const circ = 2 * Math.PI * r;
  const dash = (pctVal / 100) * circ * 0.75;
  return (
    <div style={{ textAlign: "center" }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={C.border} strokeWidth="5"
          strokeDasharray={`${circ * 0.75} ${circ * 0.25}`} strokeLinecap="round"
          transform={`rotate(135 ${size / 2} ${size / 2})`} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth="5"
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
          transform={`rotate(135 ${size / 2} ${size / 2})`}
          style={{ transition: "stroke-dasharray 1s ease" }} />
        <text x={size / 2} y={size / 2 + 2} textAnchor="middle" fill={C.text} fontSize="16" fontWeight="700"
          fontFamily="'JetBrains Mono', monospace">{value}</text>
      </svg>
      <div style={{ fontSize: 10, color: C.textDim, marginTop: -4 }}>{label}</div>
    </div>
  );
}

// ── Progress Bar ──
function ProgressBar({ value, max = 100, color = C.accent, height = 6 }) {
  return (
    <div style={{ background: C.border, borderRadius: height / 2, height, width: "100%", overflow: "hidden" }}>
      <div style={{
        width: `${(value / max) * 100}%`, height: "100%", background: color,
        borderRadius: height / 2, transition: "width 0.8s ease"
      }} />
    </div>
  );
}

// ── Card Wrapper ──
function Card({ children, style, glow, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: C.card, border: `1px solid ${C.border}`, borderRadius: 12,
      padding: 20, position: "relative", overflow: "hidden",
      boxShadow: glow ? `0 0 20px ${glow}` : "none",
      cursor: onClick ? "pointer" : "default",
      transition: "transform 0.2s, box-shadow 0.3s",
      ...style,
    }}>
      {children}
    </div>
  );
}

// ── Section Header ──
function SectionHeader({ title, subtitle, action }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 16 }}>
      <div>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: C.text, fontFamily: "'JetBrains Mono', monospace" }}>{title}</h2>
        {subtitle && <p style={{ margin: "4px 0 0", fontSize: 12, color: C.textMuted }}>{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

// ── Badge ──
function Badge({ text, color = C.accent }) {
  return (
    <span style={{
      display: "inline-block", padding: "2px 8px", borderRadius: 4,
      fontSize: 10, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace",
      background: color + "22", color, border: `1px solid ${color}44`,
      textTransform: "uppercase", letterSpacing: "0.5px",
    }}>{text}</span>
  );
}

// ── Tabs ──
function TabBar({ active, onChange }) {
  return (
    <div style={{
      display: "flex", gap: 2, padding: "4px", background: C.surface,
      borderRadius: 10, marginBottom: 24, overflowX: "auto", WebkitOverflowScrolling: "touch",
    }}>
      {TABS.map(tab => (
        <button key={tab} onClick={() => onChange(tab)} style={{
          flex: "0 0 auto", padding: "10px 18px", border: "none", borderRadius: 8,
          background: active === tab ? C.card : "transparent",
          color: active === tab ? C.accent : C.textMuted,
          fontSize: 13, fontWeight: 600, cursor: "pointer",
          fontFamily: "'JetBrains Mono', monospace",
          transition: "all 0.2s", whiteSpace: "nowrap",
          boxShadow: active === tab ? `0 0 12px ${C.accentDim}` : "none",
        }}>
          {tab}
        </button>
      ))}
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// DASHBOARD TAB
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function DashboardTab() {
  const sparkData = () => Array.from({ length: 20 }, () => Math.random() * 40 + 60);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      {/* Market Pulse */}
      <SectionHeader title="◉ MARKET PULSE" subtitle="Real-time overview" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 12 }}>
        {MARKET_DATA.map(m => (
          <Card key={m.sym} style={{ padding: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: C.text, fontFamily: "'JetBrains Mono', monospace" }}>{m.sym}</div>
                <div style={{ fontSize: 10, color: C.textMuted }}>{m.name}</div>
              </div>
              <Sparkline data={sparkData()} color={m.chg >= 0 ? C.accent : C.danger} />
            </div>
            <div style={{ marginTop: 10, display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
              <span style={{ fontSize: 18, fontWeight: 700, color: C.text, fontFamily: "'JetBrains Mono', monospace" }}>{fmt(m.price)}</span>
              <span style={{ fontSize: 13, fontWeight: 600, color: pctColor(m.chg), fontFamily: "'JetBrains Mono', monospace" }}>{pct(m.chg)}</span>
            </div>
            <div style={{ fontSize: 10, color: C.textMuted, marginTop: 4 }}>Vol: {m.vol}</div>
          </Card>
        ))}
      </div>

      {/* Cycle Alert Banner */}
      <Card glow={C.warnDim} style={{ background: `linear-gradient(135deg, ${C.card}, #1a1a2e)`, borderColor: C.warn + "44" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
          <div style={{ fontSize: 32 }}>⚠</div>
          <div style={{ flex: 1, minWidth: 200 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: C.warn, fontFamily: "'JetBrains Mono', monospace" }}>CYCLE CONVERGENCE ALERT</div>
            <div style={{ fontSize: 12, color: C.textDim, marginTop: 4 }}>4 major cycles converging Q1 2026 — Armstrong Pi, Shemitah, Benner Panic Year, 262-day financial cycle. Highest probability turning point since 2008.</div>
          </div>
          <Badge text="4 Cycles" color={C.warn} />
        </div>
      </Card>

      {/* Quick Stats Row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12 }}>
        <Card style={{ padding: 16, textAlign: "center" }}>
          <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase", letterSpacing: 1 }}>MTT Passing</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: C.accent, fontFamily: "'JetBrains Mono', monospace", marginTop: 4 }}>5/8</div>
        </Card>
        <Card style={{ padding: 16, textAlign: "center" }}>
          <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase", letterSpacing: 1 }}>Stage 2 Count</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: C.blue, fontFamily: "'JetBrains Mono', monospace", marginTop: 4 }}>6</div>
        </Card>
        <Card style={{ padding: 16, textAlign: "center" }}>
          <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase", letterSpacing: 1 }}>Watchlist P&L</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: C.accent, fontFamily: "'JetBrains Mono', monospace", marginTop: 4 }}>+18.2%</div>
        </Card>
        <Card style={{ padding: 16, textAlign: "center" }}>
          <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase", letterSpacing: 1 }}>Days to Convergence</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: C.warn, fontFamily: "'JetBrains Mono', monospace", marginTop: 4 }}>~42</div>
        </Card>
      </div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// MTT SCANNER TAB
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function MTTTab() {
  const [selected, setSelected] = useState(null);
  const [filter, setFilter] = useState("all");

  const filtered = filter === "pass" ? MTT_RESULTS.filter(r => r.pass) :
                   filter === "fail" ? MTT_RESULTS.filter(r => !r.pass) : MTT_RESULTS;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <SectionHeader title="◉ MINERVINI TREND TEMPLATE"
        subtitle="Stocks screened against Mark Minervini's 8-point checklist + RS ranking"
        action={
          <div style={{ display: "flex", gap: 6 }}>
            {["all", "pass", "fail"].map(f => (
              <button key={f} onClick={() => setFilter(f)} style={{
                padding: "4px 12px", border: `1px solid ${filter === f ? C.accent : C.border}`,
                borderRadius: 6, background: filter === f ? C.accentDim : "transparent",
                color: filter === f ? C.accent : C.textMuted, fontSize: 11, fontWeight: 600,
                cursor: "pointer", fontFamily: "'JetBrains Mono', monospace", textTransform: "uppercase",
              }}>{f}</button>
            ))}
          </div>
        }
      />

      {/* Criteria Legend */}
      <Card style={{ padding: 14 }}>
        <div style={{ fontSize: 10, color: C.textMuted, fontFamily: "'JetBrains Mono', monospace", lineHeight: 1.8 }}>
          <strong style={{ color: C.accent }}>MTT CRITERIA:</strong> Price {'>'} 50 SMA {'>'} 150 SMA {'>'} 200 SMA · 200 SMA trending up 1mo+ · Price within 25% of 52wk high · Price {'>'} 30% above 52wk low · RS Rating ≥ 70
        </div>
      </Card>

      {/* Results Table */}
      <div style={{ overflowX: "auto", WebkitOverflowScrolling: "touch" }}>
        <table style={{ width: "100%", borderCollapse: "separate", borderSpacing: "0 4px", minWidth: 700 }}>
          <thead>
            <tr>
              {["Symbol", "Price", "RS", "Stage", "50 SMA", "150 SMA", "200 SMA", "Score", "Status"].map(h => (
                <th key={h} style={{
                  padding: "8px 12px", fontSize: 10, color: C.textMuted, fontWeight: 600,
                  textAlign: h === "Symbol" ? "left" : "right", fontFamily: "'JetBrains Mono', monospace",
                  textTransform: "uppercase", letterSpacing: "0.5px", borderBottom: `1px solid ${C.border}`,
                }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(r => (
              <tr key={r.sym} onClick={() => setSelected(r.sym === selected ? null : r.sym)}
                style={{
                  cursor: "pointer", background: selected === r.sym ? C.accentDim : C.card,
                  transition: "background 0.2s",
                }}>
                <td style={{ padding: "10px 12px", borderRadius: "8px 0 0 8px" }}>
                  <span style={{ fontWeight: 700, color: C.text, fontFamily: "'JetBrains Mono', monospace", fontSize: 14 }}>{r.sym}</span>
                </td>
                <td style={{ padding: "10px 12px", textAlign: "right", fontFamily: "'JetBrains Mono', monospace", fontSize: 13, color: C.text }}>{fmt(r.price)}</td>
                <td style={{ padding: "10px 12px", textAlign: "right" }}>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, color: r.rs >= 90 ? C.accent : r.rs >= 80 ? C.warn : C.textDim }}>{r.rs}</span>
                </td>
                <td style={{ padding: "10px 12px", textAlign: "right" }}>
                  <Badge text={`S${r.stage}`} color={r.stage === 2 ? C.accent : r.stage === 1 ? C.blue : C.warn} />
                </td>
                <td style={{ padding: "10px 12px", textAlign: "right", fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: C.textDim }}>{fmt(r.sma50)}</td>
                <td style={{ padding: "10px 12px", textAlign: "right", fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: C.textDim }}>{fmt(r.sma150)}</td>
                <td style={{ padding: "10px 12px", textAlign: "right", fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: C.textDim }}>{fmt(r.sma200)}</td>
                <td style={{ padding: "10px 12px", textAlign: "right" }}>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 14, fontWeight: 700, color: r.score >= 8 ? C.accent : r.score >= 6 ? C.warn : C.danger }}>{fmt(r.score, 1)}</span>
                </td>
                <td style={{ padding: "10px 12px", textAlign: "right", borderRadius: "0 8px 8px 0" }}>
                  <Badge text={r.pass ? "PASS" : "FAIL"} color={r.pass ? C.accent : C.danger} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Detail Panel */}
      {selected && (() => {
        const r = MTT_RESULTS.find(x => x.sym === selected);
        if (!r) return null;
        const checks = [
          { label: "Price > 50 SMA", pass: r.price > r.sma50 },
          { label: "50 SMA > 150 SMA", pass: r.sma50 > r.sma150 },
          { label: "150 SMA > 200 SMA", pass: r.sma150 > r.sma200 },
          { label: "200 SMA trending up", pass: r.stage <= 2 },
          { label: "Within 25% of 52wk high", pass: r.price >= r.high52 * 0.75 },
          { label: "30%+ above 52wk low", pass: r.price >= r.low52 * 1.3 },
          { label: "RS Rating ≥ 70", pass: r.rs >= 70 },
        ];
        return (
          <Card glow={r.pass ? C.accentDim : C.dangerDim}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 18, fontWeight: 700, color: C.text }}>
                {r.sym} <span style={{ fontSize: 12, color: C.textMuted }}>— Detailed Breakdown</span>
              </div>
              <Gauge value={r.score} max={10} label="SCORE" color={r.pass ? C.accent : C.danger} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 8 }}>
              {checks.map((c, i) => (
                <div key={i} style={{
                  display: "flex", alignItems: "center", gap: 8, padding: "6px 10px",
                  background: c.pass ? C.accentDim : C.dangerDim, borderRadius: 6,
                }}>
                  <span style={{ fontSize: 14 }}>{c.pass ? "✓" : "✗"}</span>
                  <span style={{ fontSize: 12, color: c.pass ? C.accent : C.danger, fontFamily: "'JetBrains Mono', monospace" }}>{c.label}</span>
                </div>
              ))}
            </div>
          </Card>
        );
      })()}
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// CYCLE ENGINE TAB
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function CycleTab() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <SectionHeader title="◉ CYCLE CONVERGENCE ENGINE"
        subtitle="Armstrong · Shemitah · Mayan · Kondratieff · Benner · 262-Day" />

      {/* Convergence Zones */}
      <Card glow={C.dangerDim} style={{ borderColor: C.danger + "44" }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: C.danger, fontFamily: "'JetBrains Mono', monospace", marginBottom: 12 }}>
          ▲ CONVERGENCE ZONES
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {CONVERGENCE_ZONES.map((z, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{
                width: 10, height: 10, borderRadius: "50%",
                background: z.severity === "critical" ? C.danger : z.severity === "high" ? C.warn : C.blue,
                boxShadow: `0 0 8px ${z.severity === "critical" ? C.danger : z.severity === "high" ? C.warn : C.blue}`,
              }} />
              <div style={{ flex: 1 }}>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 700, color: C.text }}>{z.date}</span>
                <span style={{ fontSize: 12, color: C.textDim, marginLeft: 8 }}>— {z.label}</span>
              </div>
              <Badge text={`${z.cycles} cycles`} color={z.severity === "critical" ? C.danger : z.severity === "high" ? C.warn : C.blue} />
            </div>
          ))}
        </div>
      </Card>

      {/* Individual Cycles */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 12 }}>
        {CYCLES.map(c => (
          <Card key={c.name}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: c.color, fontFamily: "'JetBrains Mono', monospace" }}>{c.name}</div>
                <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>Phase: {c.phase}</div>
              </div>
              <Gauge value={c.confidence} max={100} label="CONF" color={c.color} size={60} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
              <div>
                <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase" }}>Current</div>
                <div style={{ fontSize: 12, color: C.text, fontFamily: "'JetBrains Mono', monospace", marginTop: 2 }}>{c.current}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase" }}>Next Turn</div>
                <div style={{ fontSize: 12, color: c.color, fontFamily: "'JetBrains Mono', monospace", marginTop: 2 }}>{c.next}</div>
              </div>
            </div>
            <div style={{ marginTop: 10 }}>
              <ProgressBar value={c.confidence} color={c.color} />
            </div>
          </Card>
        ))}
      </div>

      {/* Sacred Geometry Note */}
      <Card style={{ background: `linear-gradient(135deg, #1a1a2e, ${C.card})`, borderColor: C.purple + "44" }}>
        <div style={{ fontSize: 12, color: C.purple, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", marginBottom: 8 }}>
          ✦ SACRED GEOMETRY RESONANCE
        </div>
        <div style={{ fontSize: 12, color: C.textDim, lineHeight: 1.7 }}>
          The 2026 convergence aligns with multiple sacred geometric ratios: the Pi ratio (3.14159 × 2.73 = 8.577 ≈ 8.6yr Armstrong cycle),
          the Fibonacci 2584-day market rhythm, and the Mayan K'atun transition entering 1 Ajaw — historically associated with
          civilizational transformation periods. The 129-year master cycle from 1896 also reaches a major inflection node.
        </div>
      </Card>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// STAGE ANALYSIS TAB
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function StageTab() {
  const stages = [
    { n: 1, name: "Basing", desc: "Accumulation phase. Smart money buying. Flat 200 SMA.", color: C.blue, count: 1, stocks: ["CRK"] },
    { n: 2, name: "Advancing", desc: "Mark-up phase. Price > rising 200 SMA. Volume expansion.", color: C.accent, count: 6, stocks: ["NVDA", "ACMR", "PLTR", "TSLA", "COIN", "MSTR"] },
    { n: 3, name: "Topping", desc: "Distribution phase. Erratic price action near 200 SMA.", color: C.warn, count: 1, stocks: ["AAPL"] },
    { n: 4, name: "Declining", desc: "Mark-down phase. Price below falling 200 SMA. Avoid.", color: C.danger, count: 0, stocks: [] },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <SectionHeader title="◉ WEINSTEIN STAGE ANALYSIS"
        subtitle="Stan Weinstein's method — identify the current market phase for each position" />

      {/* Stage Overview */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12 }}>
        {stages.map(s => (
          <Card key={s.n} glow={s.count > 0 ? s.color + "33" : undefined} style={{ borderColor: s.color + "44" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
              <div>
                <Badge text={`Stage ${s.n}`} color={s.color} />
                <div style={{ fontSize: 15, fontWeight: 700, color: C.text, marginTop: 6, fontFamily: "'JetBrains Mono', monospace" }}>{s.name}</div>
              </div>
              <div style={{
                width: 44, height: 44, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
                background: s.color + "22", border: `2px solid ${s.color}`, fontFamily: "'JetBrains Mono', monospace",
                fontSize: 20, fontWeight: 800, color: s.color,
              }}>{s.count}</div>
            </div>
            <div style={{ fontSize: 11, color: C.textDim, lineHeight: 1.5, marginBottom: 8 }}>{s.desc}</div>
            {s.stocks.length > 0 && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                {s.stocks.map(sym => (
                  <span key={sym} style={{
                    padding: "2px 8px", background: s.color + "22", borderRadius: 4,
                    fontSize: 11, fontWeight: 600, color: s.color, fontFamily: "'JetBrains Mono', monospace",
                  }}>{sym}</span>
                ))}
              </div>
            )}
          </Card>
        ))}
      </div>

      {/* Zweig Breadth Thrust */}
      <Card>
        <SectionHeader title="ZWEIG BREADTH THRUST" subtitle="Martin Zweig's momentum confirmation" />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16 }}>
          <div>
            <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase" }}>10-Day Breadth</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: C.accent, fontFamily: "'JetBrains Mono', monospace", marginTop: 4 }}>0.658</div>
            <div style={{ fontSize: 10, color: C.textDim, marginTop: 2 }}>Thrust: &gt; 0.615 ✓</div>
          </div>
          <div>
            <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase" }}>Adv/Dec Ratio</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: C.accent, fontFamily: "'JetBrains Mono', monospace", marginTop: 4 }}>2.4:1</div>
            <div style={{ fontSize: 10, color: C.textDim, marginTop: 2 }}>Bullish signal</div>
          </div>
          <div>
            <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase" }}>% Above 200 SMA</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: C.warn, fontFamily: "'JetBrains Mono', monospace", marginTop: 4 }}>62%</div>
            <div style={{ fontSize: 10, color: C.textDim, marginTop: 2 }}>Moderate breadth</div>
          </div>
        </div>
      </Card>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// WATCHLIST TAB
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function WatchlistTab() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <SectionHeader title="◉ WATCHLIST" subtitle="Active positions & tracking" />
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {WATCHLIST.map(w => {
          const pl = w.entry ? ((w.current - w.entry) / w.entry * 100) : null;
          const riskReward = w.entry ? ((w.target - w.current) / (w.current - w.stop)).toFixed(1) : null;
          const stopDist = ((w.current - w.stop) / w.current * 100).toFixed(1);
          const targetDist = ((w.target - w.current) / w.current * 100).toFixed(1);
          return (
            <Card key={w.sym}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
                <div style={{ minWidth: 120 }}>
                  <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 18, fontWeight: 700, color: C.text }}>{w.sym}</div>
                  <div style={{ fontSize: 11, color: C.textDim, marginTop: 4 }}>{w.notes}</div>
                </div>
                <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
                  <div style={{ textAlign: "center" }}>
                    <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase" }}>Current</div>
                    <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 16, fontWeight: 700, color: C.text }}>${fmt(w.current)}</div>
                  </div>
                  {w.entry && (
                    <div style={{ textAlign: "center" }}>
                      <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase" }}>Entry</div>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 16, fontWeight: 700, color: C.textDim }}>${fmt(w.entry)}</div>
                    </div>
                  )}
                  <div style={{ textAlign: "center" }}>
                    <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase" }}>Stop</div>
                    <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 16, fontWeight: 700, color: C.danger }}>${fmt(w.stop)}</div>
                    <div style={{ fontSize: 9, color: C.danger }}>-{stopDist}%</div>
                  </div>
                  <div style={{ textAlign: "center" }}>
                    <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase" }}>Target</div>
                    <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 16, fontWeight: 700, color: C.accent }}>${fmt(w.target)}</div>
                    <div style={{ fontSize: 9, color: C.accent }}>+{targetDist}%</div>
                  </div>
                  {pl != null && (
                    <div style={{ textAlign: "center" }}>
                      <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase" }}>P&L</div>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 16, fontWeight: 700, color: pctColor(pl) }}>{pct(pl)}</div>
                    </div>
                  )}
                  {riskReward && (
                    <div style={{ textAlign: "center" }}>
                      <div style={{ fontSize: 10, color: C.textMuted, textTransform: "uppercase" }}>R:R</div>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 16, fontWeight: 700, color: C.purple }}>{riskReward}:1</div>
                    </div>
                  )}
                </div>
              </div>
              {/* Visual stop/target bar */}
              <div style={{ marginTop: 14, position: "relative", height: 8, background: C.border, borderRadius: 4 }}>
                <div style={{
                  position: "absolute", left: 0, top: 0, height: "100%", borderRadius: 4,
                  width: w.entry ? `${Math.min(((w.current - w.stop) / (w.target - w.stop)) * 100, 100)}%` : "50%",
                  background: `linear-gradient(90deg, ${C.danger}, ${C.warn}, ${C.accent})`,
                  transition: "width 0.8s ease",
                }} />
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
                <span style={{ fontSize: 9, color: C.danger, fontFamily: "'JetBrains Mono', monospace" }}>STOP</span>
                <span style={{ fontSize: 9, color: C.accent, fontFamily: "'JetBrains Mono', monospace" }}>TARGET</span>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// MAIN APP
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export default function TradingHub() {
  const [tab, setTab] = useState("Dashboard");
  const [clock, setClock] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{
      minHeight: "100vh", background: C.bg, color: C.text,
      fontFamily: "'Outfit', -apple-system, sans-serif",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800&family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />

      {/* Header */}
      <header style={{
        padding: "16px 24px", background: C.surface,
        borderBottom: `1px solid ${C.border}`,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        position: "sticky", top: 0, zIndex: 100, backdropFilter: "blur(12px)",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center",
            background: `linear-gradient(135deg, ${C.accent}, ${C.blue})`, fontSize: 16, fontWeight: 800,
            color: C.bg, fontFamily: "'JetBrains Mono', monospace",
          }}>Σ</div>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "-0.5px" }}>
              SIGMA<span style={{ color: C.accent }}>HUB</span>
            </div>
            <div style={{ fontSize: 9, color: C.textMuted, letterSpacing: "2px", textTransform: "uppercase" }}>Cycles · Trends · Edge</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: C.text, fontFamily: "'JetBrains Mono', monospace" }}>
              {clock.toLocaleTimeString("en-US", { hour12: false })}
            </div>
            <div style={{ fontSize: 10, color: C.textMuted }}>
              {clock.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" })}
            </div>
          </div>
          <div style={{
            width: 8, height: 8, borderRadius: "50%", background: C.accent,
            boxShadow: `0 0 8px ${C.accent}`, animation: "pulse 2s infinite",
          }} />
        </div>
      </header>

      {/* Content */}
      <main style={{ maxWidth: 1200, margin: "0 auto", padding: "24px 16px 80px" }}>
        <TabBar active={tab} onChange={setTab} />
        {tab === "Dashboard" && <DashboardTab />}
        {tab === "MTT Scanner" && <MTTTab />}
        {tab === "Cycle Engine" && <CycleTab />}
        {tab === "Stage Analysis" && <StageTab />}
        {tab === "Watchlist" && <WatchlistTab />}
      </main>

      {/* PWA Install hint */}
      <div style={{
        position: "fixed", bottom: 16, left: "50%", transform: "translateX(-50%)",
        background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10,
        padding: "8px 16px", fontSize: 10, color: C.textMuted,
        fontFamily: "'JetBrains Mono', monospace", zIndex: 50,
        boxShadow: `0 4px 24px rgba(0,0,0,0.5)`,
      }}>
        SIGMAHUB v1.0 — PWA Ready
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: ${C.bg}; }
        ::-webkit-scrollbar-thumb { background: ${C.border}; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: ${C.borderLight}; }
        @media (max-width: 640px) {
          main { padding: 16px 12px 80px !important; }
        }
      `}</style>
    </div>
  );
}
